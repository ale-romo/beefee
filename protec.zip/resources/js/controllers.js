/*
    AUTHOR: MINT IT MEDIA
    http://mintitmedia.cm

    File with MINT functions
*/
$(window).load(function(){
});
